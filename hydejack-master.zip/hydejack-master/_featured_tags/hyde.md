---
layout: list
title: Hyde
slug: hyde
menu: true
order: 1
description: >
  Hyde is a brazen two-column Jekyll theme that pairs a prominent sidebar with uncomplicated content.
  It’s based on Poole, the Jekyll butler.
  Open `_featured_tags/hyde.md` to edit this text.

# http://jsfiddle.net/LPxrT/
image: 'data:image/gif;base64,R0lGODlhAQABAPAAACAgIP///yH5BAAAAAAALAAAAAABAAEAAAICRAEAOw=='
color: '#268bd2'
---
